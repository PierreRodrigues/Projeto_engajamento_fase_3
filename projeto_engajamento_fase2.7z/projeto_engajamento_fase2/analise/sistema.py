# analise/sistema.py

from entidades.plataforma import Plataforma
from entidades.conteudo import Video, Podcast, Artigo
from entidades.interacao import Interacao
from entidades.usuario import Usuario

import csv

class SistemaAnaliseEngajamento:
    VERSAO_ANALISE = "2.0"

    def __init__(self):
        self.__plataformas_registradas = {}
        self.__conteudos_registrados = {}
        self.__usuarios_registrados = {}
        self.__proximo_id_plataforma = 1

    def cadastrar_plataforma(self, nome_plataforma):
        if nome_plataforma in self.__plataformas_registradas:
            return self.__plataformas_registradas[nome_plataforma]
        plataforma = Plataforma(nome_plataforma, self.__proximo_id_plataforma)
        self.__proximo_id_plataforma += 1
        self.__plataformas_registradas[nome_plataforma] = plataforma
        return plataforma

    def obter_plataforma(self, nome_plataforma):
        return self.__plataformas_registradas.get(nome_plataforma) or self.cadastrar_plataforma(nome_plataforma)

    def listar_plataformas(self):
        return list(self.__plataformas_registradas.values())

    def _carregar_interacoes_csv(self, caminho_arquivo):
        with open(caminho_arquivo, 'r', encoding='utf-8') as f:
            leitor = csv.DictReader(f)
            return list(leitor)

    def processar_interacoes_do_csv(self, caminho_arquivo):
        linhas = self._carregar_interacoes_csv(caminho_arquivo)
        for linha in linhas:
            try:
                id_conteudo = int(linha['id_conteudo'])
                nome_conteudo = linha['nome_conteudo']
                tipo = linha.get('tipo_conteudo', 'video')  # default

                if id_conteudo not in self.__conteudos_registrados:
                    if tipo == 'video':
                        conteudo = Video(id_conteudo, nome_conteudo, 300)
                    elif tipo == 'podcast':
                        conteudo = Podcast(id_conteudo, nome_conteudo, 1800)
                    else:
                        conteudo = Artigo(id_conteudo, nome_conteudo, 600)
                    self.__conteudos_registrados[id_conteudo] = conteudo
                else:
                    conteudo = self.__conteudos_registrados[id_conteudo]

                id_usuario = int(linha['id_usuario'])
                if id_usuario not in self.__usuarios_registrados:
                    self.__usuarios_registrados[id_usuario] = Usuario(id_usuario)
                usuario = self.__usuarios_registrados[id_usuario]

                plataforma = self.obter_plataforma(linha.get('nome_plataforma', 'Globo'))

                interacao = Interacao(
                    conteudo_associado=conteudo,
                    plataforma_interacao=plataforma,
                    id_usuario=id_usuario,
                    timestamp_interacao=linha['timestamp_interacao'],
                    tipo_interacao=linha['tipo_interacao'],
                    watch_duration_seconds=linha.get('watch_duration_seconds', 0),
                    comment_text=linha.get('comment_text', '')
                )
                conteudo.adicionar_interacao(interacao)
                usuario.registrar_interacao(interacao)

            except Exception as e:
                print(f"Erro ao processar linha: {linha}\nErro: {e}")

    def gerar_relatorio_engajamento_conteudos(self):
        for conteudo in self.__conteudos_registrados.values():
            print(f"\nConteúdo: {conteudo.nome_conteudo}")
            print("Total Interações Engajamento:", conteudo.calcular_total_interacoes_engajamento())
            print("Tempo Total de Consumo:", conteudo.calcular_tempo_total_consumo())
            print("Tempo Médio:", conteudo.calcular_media_tempo_consumo())
            print("Comentários:", conteudo.listar_comentarios())