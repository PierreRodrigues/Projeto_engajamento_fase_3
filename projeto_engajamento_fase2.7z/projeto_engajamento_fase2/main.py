# main.py
from analise.sistema import SistemaAnaliseEngajamento
from entidades.usuario import Usuario
from entidades.conteudo import Podcast, Video, Artigo
from entidades.interacao import Interacao
from entidades.plataforma import Plataforma

    

def main():
    # Inicializar o sistema de análise de engajamento
    # Processar interações do CSV
    sistema = SistemaAnaliseEngajamento()
    sistema.processar_interacoes_do_csv('interacoes_globo.csv')
    # Gerar relatórios de engajamento e atividade dos usuários
    sistema.gerar_relatorio_engajamento_conteudos()
    sistema.gerar_relatorio_atividade_usuarios()
    # Identificar os top conteúdos com base no tempo total de consumo e total de interações de engajamento
    sistema.identificar_top_conteudos('tempo_total_consumo', n=5)
    sistema.identificar_top_conteudos('total_interacoes_engajamento', n=5)

    usuario = Usuario(id_usuario=1)
    # Exemplo de uso do usuário
    podcast = Podcast(id_conteudo=1, nome_conteudo='Podcast de Teste', duracao_total_episodio_seg=3600)
    interacao = Interacao(
        dados_brutos={
            'id_usuario': usuario.id_usuario,
            'timestamp_interacao': '2023-10-01T12:00:00',
            'tipo_interacao': 'like',
            'watch_duration_seconds': 300,
            'comment_text': ''
        },
        conteudo_associado=podcast,
        plataforma_interacao= Plataforma('spotfy')
    )
    usuario.registrar_interacao(interacao)

    video = Video(id_conteudo=2, nome_conteudo='Video de Teste', duracao_total_video_seg=1800)
    interacao2 = Interacao(
        dados_brutos={
            'id_usuario': usuario.id_usuario,
            'timestamp_interacao': '2023-10-01T12:02:00',
            'tipo_interacao': 'view_start',
            'watch_duration_seconds': 1200,
            'comment_text': ''
        },
        conteudo_associado=video,
        plataforma_interacao=Plataforma('youtube')
    )
    usuario.registrar_interacao(interacao2)

    artigo = Artigo(id_conteudo=3, nome_conteudo='Artigo de Teste', tempo_leitura_estimado_seg=600)

    interacao3 = Interacao(
        dados_brutos={
            'id_usuario': usuario.id_usuario,
            'timestamp_interacao': '2023-10-01T12:05:00',
            'tipo_interacao': 'comment',
            'watch_duration_seconds': 0,
            'comment_text': 'Ótimo artigo!'
        },
        conteudo_associado=artigo,
        plataforma_interacao=Plataforma('medium')
    )

    usuario.registrar_interacao(interacao3)

    usuario.obter_interacoes_por_tipo('like')
    usuario.obter_interacoes_por_tipo('view_start')
    usuario.obter_interacoes_por_tipo('comment')
    
    
if __name__ == '__main__':
    main()