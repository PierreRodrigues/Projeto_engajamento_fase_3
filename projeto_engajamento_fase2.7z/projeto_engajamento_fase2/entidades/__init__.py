from .plataforma import Plataforma
from .conteudo import Conteudo, Video, Podcast, Artigo
from .interacao import Interacao
from .usuario import Usuario