# entidades/plataforma.py

class Plataforma:
    def __init__(self, nome_plataforma: str, id_plataforma: int = None):
        if not nome_plataforma.strip():
            raise ValueError("O nome da plataforma não pode ser vazio.")
        self.__id_plataforma = id_plataforma
        self.__nome_plataforma = nome_plataforma.strip()

    @property
    def id_plataforma(self):
        return self.__id_plataforma

    @id_plataforma.setter
    def id_plataforma(self, valor):
        self.__id_plataforma = valor

    @property
    def nome_plataforma(self):
        return self.__nome_plataforma

    @nome_plataforma.setter
    def nome_plataforma(self, valor):
        if not valor.strip():
            raise ValueError("O nome da plataforma não pode ser vazio.")
        self.__nome_plataforma = valor.strip()

    def __str__(self):
        return self.__nome_plataforma

    def __repr__(self):
        return f"Plataforma(nome='{self.__nome_plataforma}')"

    def __eq__(self, other):
        if isinstance(other, Plataforma):
            return self.__nome_plataforma == other.__nome_plataforma
        return False

    def __hash__(self):
        return hash(self.__nome_plataforma)