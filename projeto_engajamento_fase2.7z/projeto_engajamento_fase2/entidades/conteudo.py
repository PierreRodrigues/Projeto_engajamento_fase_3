# entidades/conteudo.py

class Conteudo:
    def __init__(self, id_conteudo: int, nome_conteudo: str):
        self._id_conteudo = id_conteudo
        self._nome_conteudo = nome_conteudo.strip()
        self._interacoes = []

    @property
    def id_conteudo(self):
        return self._id_conteudo

    @property
    def nome_conteudo(self):
        return self._nome_conteudo

    def adicionar_interacao(self, interacao):
        self._interacoes.append(interacao)

    def calcular_total_interacoes_engajamento(self):
        tipos = {"like", "share", "comment"}
        return sum(1 for i in self._interacoes if i.tipo_interacao in tipos)

    def calcular_contagem_por_tipo_interacao(self):
        contagem = {}
        for i in self._interacoes:
            contagem[i.tipo_interacao] = contagem.get(i.tipo_interacao, 0) + 1
        return contagem

    def calcular_tempo_total_consumo(self):
        return sum(i.watch_duration_seconds for i in self._interacoes)

    def calcular_media_tempo_consumo(self):
        tempos = [i.watch_duration_seconds for i in self._interacoes if i.watch_duration_seconds > 0]
        return sum(tempos) / len(tempos) if tempos else 0

    def listar_comentarios(self):
        return [i.comment_text for i in self._interacoes if i.tipo_interacao == "comment"]

    def __str__(self):
        return self._nome_conteudo

    def __repr__(self):
        return f"Conteudo(nome='{self._nome_conteudo}')"

class Video(Conteudo):
    def __init__(self, id_conteudo, nome_conteudo, duracao_total_video_seg):
        super().__init__(id_conteudo, nome_conteudo)
        self.__duracao_total_video_seg = duracao_total_video_seg

    @property
    def duracao_total_video_seg(self):
        return self.__duracao_total_video_seg

    def calcular_percentual_medio_assistido(self):
        media = self.calcular_media_tempo_consumo()
        if self.__duracao_total_video_seg == 0:
            return 0
        return round((media / self.__duracao_total_video_seg) * 100, 2)

class Podcast(Conteudo):
    def __init__(self, id_conteudo, nome_conteudo, duracao_total_episodio_seg=0):
        super().__init__(id_conteudo, nome_conteudo)
        self.__duracao_total_episodio_seg = duracao_total_episodio_seg

    @property
    def duracao_total_episodio_seg(self):
        return self.__duracao_total_episodio_seg

class Artigo(Conteudo):
    def __init__(self, id_conteudo, nome_conteudo, tempo_leitura_estimado_seg):
        super().__init__(id_conteudo, nome_conteudo)
        self.__tempo_leitura_estimado_seg = tempo_leitura_estimado_seg

    @property
    def tempo_leitura_estimado_seg(self):
        return self.__tempo_leitura_estimado_seg