# entidades/interacao.py

from datetime import datetime

class Interacao:
    TIPOS_INTERACAO_VALIDOS = {"view_start", "like", "share", "comment"}
    _id_counter = 1

    def __init__(self, conteudo_associado, plataforma_interacao, id_usuario, timestamp_interacao,
                 tipo_interacao, watch_duration_seconds=0, comment_text=""):

        self.__interacao_id = Interacao._id_counter
        Interacao._id_counter += 1

        self.__conteudo_associado = conteudo_associado
        self.__plataforma_interacao = plataforma_interacao

        self.__id_usuario = int(id_usuario)
        self.__timestamp_interacao = datetime.fromisoformat(timestamp_interacao)
        self.__tipo_interacao = tipo_interacao if tipo_interacao in Interacao.TIPOS_INTERACAO_VALIDOS else "view_start"
        self.__watch_duration_seconds = max(0, int(watch_duration_seconds))
        self.__comment_text = comment_text.strip()

    @property
    def interacao_id(self):
        return self.__interacao_id

    @property
    def conteudo_associado(self):
        return self.__conteudo_associado

    @property
    def id_usuario(self):
        return self.__id_usuario

    @property
    def timestamp_interacao(self):
        return self.__timestamp_interacao

    @property
    def plataforma_interacao(self):
        return self.__plataforma_interacao

    @property
    def tipo_interacao(self):
        return self.__tipo_interacao

    @property
    def watch_duration_seconds(self):
        return self.__watch_duration_seconds

    @property
    def comment_text(self):
        return self.__comment_text

    def __str__(self):
        return f"Interacao({self.__tipo_interacao})"

    def __repr__(self):
        return f"Interacao(id={self.__interacao_id}, tipo={self.__tipo_interacao})"